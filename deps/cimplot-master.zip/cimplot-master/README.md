# cimplot

This is a c-api wrapper for implot (https://github.com/epezent/implot) which is a plotter for Dear ImGui (https://github.com/ocornut/imgui)

implot is a submodule of this repo. To do generation again in case implot is changed, you should update implot, make sure that cimgui repository is a sibling folder to this repository folder and execute generator/generator.bat(.sh)
